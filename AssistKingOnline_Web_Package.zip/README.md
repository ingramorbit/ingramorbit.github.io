# AssistKingOnline — Ready-to-Upload Web Package

This bundle contains a simple static homepage preview with your latest desktop and mobile designs embedded,
plus a favicon. Upload everything to your GitHub Pages repository (or any host) and it will work immediately.

## Files
- `index.html` — static homepage preview using your AssistKingOnline branding
- `assets/assistkingonline_desktop.png` — final desktop mockup
- `assets/assistkingonline_mobile.png` — final mobile mockup
- `assets/favicon.ico` — crown favicon

## Upload to GitHub Pages
1. Open your repo (e.g., `ingramorbit.github.io`).
2. Click **Add file → Upload files**.
3. Drag the **contents of this folder** (all files and the `assets` folder) into the uploader.
4. Click **Commit changes**.
5. In the repo: **Settings → Pages → Custom domain** → `assistkingonline.com` → Save.
6. Ensure **Enforce HTTPS** is checked when available.

You're live at https://assistkingonline.com once DNS is verified.
